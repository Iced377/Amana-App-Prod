# Amana

This is Amana, a NextJS application built in Firebase Studio.

To get started, take a look at src/app/page.tsx.
